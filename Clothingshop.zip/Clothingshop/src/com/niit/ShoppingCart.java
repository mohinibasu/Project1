package com.niit;

import java.util.ArrayList;

public class ShoppingCart {
	
	public static void main(String[] args){
		
		
		
		ArrayList<Product> cart =new ArrayList<>();
		Product p1=new Product("MP3 Player","P01",300,40);
		Product p2=new Product("Mobile","P02",9000,34);
		Product p3=new Product("Shirt","P03",1100,23);
	    cart.add(p1);
	    cart.add(p2);
	    cart.add(p3);
	    for(Product p:cart)
	    {
	    	
	    	
	    	System.out.println(p.getName() + p.getPrice());
	    }
	    
		
	}

}
