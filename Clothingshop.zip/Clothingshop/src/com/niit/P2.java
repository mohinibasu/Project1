package com.niit;

public class P2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
