package com.niit;

public class P1 {

	private String name;
	private String id;
	private int price;
	private int noof;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getNoof() {
		return noof;
	}
	public void setNoof(int noof) {
		this.noof = noof;
	}
	
}
	//getter setter






	