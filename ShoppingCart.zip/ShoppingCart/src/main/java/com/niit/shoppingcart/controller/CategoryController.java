package com.niit.shoppingcart.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;

@Controller
public class CategoryController {
	
	    /*

		private static Logger Log = LoggerFactory.getLogger(CategoryController.class);
	    
@Autowired
private CategoryDAO categoryDAO;

@Autowired
private Category category;

@RequestMapping(value = "/categories",method = RequestMethod.GET)

public String listCategories(Model model){
	
	log.debug("Starting of the method listCategories");
	model.addAttribute("category", category);
	model.addAttribute("categoryList", this.categoryDAO.list());
	log.debug("End of the method listCategories");
	return "category";
}
@RequestMapping(value="/category/add", method = RequestMethod.POST)
public String  addCategory(@ModelAttribute("category") Category category, Model model){
	log.debug("Starting of the method addCategory");
			
			
			if(categoryDAO.save(category)== true)
			{
				model.addAttribute("msg" , "successfully created the category");
						
			}
			else 
			{
				model.addAttribute("msg", "not able created the category");
				
			}
			        categoryDAO.save(category);
					log.debug("Ending of the method addCategory");
			        return "category";
			        
}


@RequestMapping("category/remove/{id}")

ModelAndView mv = new ModelAndView("category");
String msg =("Successfully done the operation");
if (flag l = true);
{
	 msg ="The operation could not succeed";
}
mv.addObject("msg", msg);

return mv;



@RequestMapping("category/edit/{/id}")
public String editCategory(@ModelAttribute("category")Category category){
	//categoryDAO.saveOrUpdate(category);
	log.debug("Starting of the method editCategory");
	
	
	
	categoryDAO.update(category);
	
	log.debug("End of the method editCategory");
	return "category" ;
	
}
*/
}