package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

@Controller
public class ProductController {
	/*
@Autowired 
private ProductDAO productDAO; 

@Autowired
private Product product;

@RequestMapping(value = "/product/add", method = RequestMethod.GET)
public String addProduct(@ModelAttribute("product") Product product , Model model){
	
	model.addAttribute("product", product);
	model.addAttribute("productList", this.productDAO.list());
	return "product";
	
}


	
*/
}
