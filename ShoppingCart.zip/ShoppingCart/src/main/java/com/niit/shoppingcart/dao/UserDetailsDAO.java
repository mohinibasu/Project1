package com.niit.shoppingcart.dao;

import java.util.List;

import org.springframework.stereotype.Repository;


import com.niit.shoppingcart.model.UserDetails;

@Repository		//@Repository annotation is a specialization of the @Component annotation with similar use and functionality...
public interface UserDetailsDAO{
	
	
	
		
	public boolean update(UserDetails userdetails);	//to update the record that exist..
	
	public boolean saveOrUpdate(UserDetails userdetails);
	
	public boolean delete(UserDetails userdetails);	//to delete the record from category..
	
	public UserDetails get(String id);
	
	public List<UserDetails> list();

	public boolean save(UserDetails userdetails);
	



}



