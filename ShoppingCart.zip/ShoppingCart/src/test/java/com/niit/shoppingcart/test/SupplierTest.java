package com.niit.shoppingcart.test;


	import org.springframework.context.annotation.AnnotationConfigApplicationContext;

	import com.niit.shoppingcart.dao.SupplierDAO;
	import com.niit.shoppingcart.model.Supplier;

	public class SupplierTest {

		public static void main(String[] args) {
			
			
			@SuppressWarnings("resource")
			AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
			context.scan("com.niit");
			context.refresh();
			
	
			
			SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
			//Supplier supplier = (Supplier) context.getBean("supplier");
			Supplier s = new Supplier();
			s.setId("SUP021");
			s.setName("Reliance Trendz");
			s.setAddress("Mumbai");
			
			if(supplierDAO.save(s) == true){
				System.out.println("Supplier created successfully...");
			}
			else{
				System.out.println("Not able to create supplier...");
	}
			
			System.out.println(supplierDAO.list());
			Supplier supplier3 = new Supplier();
			supplier3.setId("SUP003");
			System.out.println(supplierDAO.delete(supplier3));
			
			
			

		}

	}





