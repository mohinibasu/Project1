package com.niit.shoppingcart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;

public class CategoryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		//Here i'm going to perform basic database operations using hibernate provided functions....
		
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
	//	Category category = (Category) context.getBean("category");
		Category category = new Category();
		category.setId("CTG015");
		category.setName("CTG_name_9");
		category.setDescription("This is category001 description...");
		
		
		if(categoryDAO.save(category) == true){
			System.out.println("Category created successfully...");
		}
		else{
			System.out.println("Not able to create category...");
		}
		
	//	System.out.println(categoryDAO.list());
		
		Category category1 = new Category();
		category1.setId("CTG003");
		System.out.println(categoryDAO.delete(category1));
		
		
		
		
	}

}
