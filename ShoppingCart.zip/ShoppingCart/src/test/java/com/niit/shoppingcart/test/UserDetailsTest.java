package com.niit.shoppingcart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDetailsDAO;
import com.niit.shoppingcart.model.UserDetails;

public class UserDetailsTest {

	public static void main(String[] args) {
		

		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		
		
		UserDetailsDAO userDetailsDAO = (UserDetailsDAO) context.getBean("userDetailsDAO");
		//UserDetails userDetails = (UserDetails) context.getBean("userDetails");
		UserDetails userDetails = new UserDetails();
		userDetails.setId("USER004");
		userDetails.setName("USER_name_002");
		userDetails.setPassword("pwd002");
		userDetails.setEmail("user2@niit.com");
		userDetails.setRole("9823");
		userDetails.setAddress("Kol");
		userDetails.setEnabled(true);
				
				
		if(userDetailsDAO.save(userDetails) == true){
			System.out.println("UserDetails created successfully...");
		}
		else{
			System.out.println("Not able to create userDetails...");
		}
		
		UserDetails userDetails1 = new UserDetails();
		userDetails1.setId("USER005");
		System.out.println(userDetailsDAO.list());
		
	}

}
