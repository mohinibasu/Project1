package com.niit.collection;

public class Product {

	
	

private String name;
private String Id;
private int salary;
private int ssn;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getId() {
	return Id;
}
public void setId(String id) {
	Id = id;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public int getSsn() {
	return ssn;
}
public void setSsn(int ssn) {
	this.ssn = ssn;
}
public Product(String name, String id, int salary, int ssn) {
	super();
	this.name = name;
	Id = id;
	this.salary = salary;
	this.ssn = ssn;
}


}

