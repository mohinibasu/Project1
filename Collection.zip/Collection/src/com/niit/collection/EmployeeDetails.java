package com.niit.collection;

import java.util.ArrayList;

public class EmployeeDetails {
		
    public static void main(String[]args){
		
		
	ArrayList<Product> cart =new ArrayList<>();
	Product p1=new Product("Mukesh","P01",300,40);
	Product p2=new Product("Mohit","P02",9000,34);
	Product p3=new Product("Shyam","P03",1100,23);
	
	cart.add(p1);
	cart.add(p2);
	cart.add(p3);
	
   for(Product p:cart)
   {
		System.out.println(p.getName()+ p.getId());
		
	
   }
    }
}

	


	
	

	
	
	


